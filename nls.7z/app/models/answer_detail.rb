class AnswerDetail < ActiveRecord::Base
belongs_to :letter
belongs_to :letter_detail

end
