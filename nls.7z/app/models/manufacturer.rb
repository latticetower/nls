class Manufacturer < ActiveRecord::Base
has_many :letter_details
end
