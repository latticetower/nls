class Medicine < ActiveRecord::Base
end
