class LetterState < ActiveRecord::Base
end
