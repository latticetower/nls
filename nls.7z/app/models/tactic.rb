class Tactic < ActiveRecord::Base
end
