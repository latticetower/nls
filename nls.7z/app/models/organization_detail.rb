class OrganizationDetail < ActiveRecord::Base
belongs_to :organization
end
