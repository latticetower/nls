class Measure < ActiveRecord::Base
end
