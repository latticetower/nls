class Country < ActiveRecord::Base
has_many :letter_details
end
