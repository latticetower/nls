class SessionsController < Clearance::SessionsController

end