module TacticsHelper
end
