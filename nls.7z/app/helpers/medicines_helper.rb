module MedicinesHelper
end
