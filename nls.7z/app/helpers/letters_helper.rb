module LettersHelper
   def letter_column(detail) 
	h(detail.letter.item) 
   end
end
